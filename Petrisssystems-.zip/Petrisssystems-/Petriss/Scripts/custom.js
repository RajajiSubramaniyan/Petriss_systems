﻿function setActiveMenu(menuId) {
    $('#' + menuId).addClass('active');
}